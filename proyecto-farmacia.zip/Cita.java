import java.util.ArrayList;
class Cita {
    String fecha;
    String hora; 
    String  idtUsuario;
    ArrayList<Turno> turnos;
}